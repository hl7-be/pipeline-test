# Home - Pipeline Test IG - Belgian SNOMED Content v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://hl7-be.github.io/pipeline-test/ImplementationGuide/pipeline-test | *Version*:0.1.0 |
| Active as of 2024-01-15 | *Computable Name*:PipelineTestIG |

 This is a test FHIR Implementation Guide for validating the publication pipeline. It contains Belgian SNOMED CT content as sample artefacts. 

> **This is a test IG for pipeline validation.**This content is only for demonstrative purposes.

### Content

This publication contains:

* A [ValueSet](ValueSet-be-condition-codes.md) with Belgian SNOMED CT codes for common clinical conditions (lower abdominal pain, sulfonamide allergy, atrial septal defect, hypertension, diabetes, asthma)
* Example resources: a [Belgian Patient](Patient-ExampleBelgianPatient.md), clinical [Conditions](Condition-ExampleConditionAbdominalPain.md), and an [AllergyIntolerance](AllergyIntolerance-ExampleAllergyIntoleranceSulfonamide.md)

The top menu allows quick navigation to the different sections, and a [Table of Contents](toc.md) is provided with the entire content of this Implementation Guide. (Be aware that some pages have multiple tabs).

### Intellectual Property Considerations

 While this implementation guide and the underlying FHIR are licensed as public domain, this guide includes examples making use of terminologies such as LOINC, SNOMED CT and others which have more restrictive licensing requirements. Implementers should make themselves familiar with licensing and any other constraints of terminologies, questionnaires, and other components used as part of their implementation process. In some cases, licensing requirements may limit the systems that data captured using certain questionnaires may be shared with. 

### Disclaimer

 The specification herewith documented is a demo working specification, and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency, and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification, or its consequences. 

